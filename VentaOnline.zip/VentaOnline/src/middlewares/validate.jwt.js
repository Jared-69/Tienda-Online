const {request, response} = require('express');
const jwt = require('moment');
const moment = require('moment');
const Usuarios = require("../models/user.model");

const validateJWT = async (req  = request, res = response, next) => {
    const toekn = req.header('x-token')

    //Si el token no viene
    if(token){
        return res.status(401).send({
            message: 'No hay token en la peticion',
        })
    }
    try{
        const payload = jwt.decode(token, process.env.SECRET_KEY);
        //Se buscara por medio del id
        const userEncontrado = await Usuarios.findById(payload.uId)
        console.log(userEncontrado);

        //Veriicacion de token si expiro o no
        if(payload.exp <= moment().unix()){
            return res.status(500).send({message: 'El token se ah expirado'});
        }
        //verificar si el usuario sigue existiendo
        if(!userEncontrado){
            return res.status(401).send({
                message: "Token no valido - user no existe en la Base de Datos"
            });

        }
            // Crear un nuevo atributo en el request y se usa del lado del controller para validar si el rol
            // tiene permisos(si es igual a client o admin
            req.user = userEncontrado;

    
            next();


    }catch(error){
        throw new Error(error);
    }
};

module.exports = {validateJWT};