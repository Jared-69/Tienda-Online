'use strict'

const Usuarios = require('../models/user.model');
const bcrypt = require('bcrypt');
const { generateJWT } = require('../helpers/create-jwt');

const createUser = async(req, res) => {
    const {name, email, password} = req.body;
    try{
        let usuario = await Usuarios.findOne({email});
        if(usuario){
            return res.status(400).send({
                mesagge: 'Un usuario ya existente',
                ok: false,
                usuario: usuario,
            });

        }
        usuario = new Usuarios(req.body);

        const saltos = bcrypt.genSaltSync();
        usuario.password = bcrypt.hashSync(password, saltos);

        usuario  = await usuario.save();

        //Creacion de TOken

        const token = await generateJWT(usuario.id, usuario.username, usuario.email);
        res.status(200).send({
            mesagge: `Usuario ${usuario.username} creado con exito!`,
            usuario,
            token: token
        });

        res.status(200).send({
            ok:true,
            mesagge: `Usuario ${name} creado correctamente`,
            usuario: usuario,
        })
    }catch(error){
        console.log(error)
        res.status(500).send({
            ok: false,
            mesagge: `No se ah creado el ususario: ${name}`,
            error: error,

        })
            
        }
    }
    
    module.exports = {createUser}

