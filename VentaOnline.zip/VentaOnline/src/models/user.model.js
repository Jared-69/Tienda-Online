'use strict'

const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const UserSchema = Schema({
    name: String,
    lastname: String,
    email: String,
    password: String,
    rol: {
        type:String,
        enum: ['ADMIN', 'CLIENT'],
        required: true
    } //Se utiliza para definir una lista de valores en String
})

module.exports = mongoose.model('User', UserSchema);