'use strict'

const User = require('./src/models/user.model');
const bcrypt = require('bcrypt');
const {generateJWT} = require('./src/helpers/create-jwt');

const defaultUser = async () => {
    try{
        const user = new User();
        user.name = 'Jared';
        user.lastname = 'García';
        user.email = 'Jared@gmail.com';
        user.password = '123456';
        user.rol = 'ADMIN';


        const userEncontrado = await User.findOne({email: user.email});
        if(userEncontrado) return console.log('Admin Listo');

        //Se encriptara la contraseña
        user.password = bcrypt.hashSync(user.password, bcrypt.genSaltSync());

        //Save a token
        user = await user.save();

        if(!user) return console.log('Administrador Listo');
        return console.log('El administrador esta listo');


    }catch(error){
        console.log(error);
    }
}

module.exports = {defaultUser};